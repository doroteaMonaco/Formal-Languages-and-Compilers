int a, b, c;
float d;
