public class SymbolType {
    private int type; // 0=int, 1=double, -1=errore
    private int dim;  // -1=non array, >0=array

    public SymbolType(int type, int dim) {
        this.type = type;
        this.dim = dim;
    }

    public int getType() { return type; }
    public int getDim() { return dim; }
}
